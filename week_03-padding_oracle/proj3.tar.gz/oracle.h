int sockfd;
int Oracle_Connect();
int Oracle_Disconnect();
int Oracle_Send(unsigned char *cipher_text, int block_length);
